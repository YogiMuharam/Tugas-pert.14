<html>
	<head>
		<title>header</title>
		<link href="style.css" rel="stylesheet"
type="text/css" />
	</head>
	<body>
		<div class="container">
			<header>
				<h1>DATA BARANG</h1>
				<div class="main">
			</header>
		</div>
		</div>
	</body>
</html>