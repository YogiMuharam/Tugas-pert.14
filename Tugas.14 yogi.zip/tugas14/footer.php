<html>
	<head>
		<title>footer</title>
		<link href="style.css" rel="stylesheet"
type="text/css" />
	</head>
	<body>
		<div class="container">
			<footer>
				<p>&copy;  2020, TI STT Pelita Bangsa</p>
			</footer>
		</div>
		</div>
	</body>
</html>